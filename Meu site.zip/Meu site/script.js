const Imagens = [
  "Imagens/imagem1.jpg",
  "Imagens/imagem2.jpg",
  "Imagens/imagem3.jpeg"
];

let indiceAtual = 0;
const imgElemento = document.getElementById("imagem-carrossel");

if (imgElemento) {
  document.querySelector(".proximo").addEventListener("click", () => {
    indiceAtual = (indiceAtual + 1) % Imagens.length;
    imgElemento.src = Imagens[indiceAtual];
  });

  document.querySelector(".anterior").addEventListener("click", () => {
    indiceAtual = (indiceAtual - 1 + Imagens.length) % Imagens.length;
    imgElemento.src = Imagens[indiceAtual];
  });

  // Carrossel automático
  setInterval(() => {
    indiceAtual = (indiceAtual + 1) % Imagens.length;
    imgElemento.src = Imagens[indiceAtual];
  }, 7000);
}

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("form-contato");
  const statusDiv = document.getElementById("mensagem-status");
  const telefoneInput = document.getElementById("telefone");

  // Impedir digitação de letras no campo telefone
  telefoneInput.addEventListener("keypress", function (event) {
    const charCode = event.charCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  });

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Impede envio automático

    // Pegar os valores
    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const telefone = document.getElementById("telefone").value.trim();
    const assunto = document.getElementById("assunto").value.trim();
    const mensagem = document.getElementById("mensagem").value.trim();

    // Limpar mensagens anteriores
    statusDiv.textContent = "";
    statusDiv.style.color = "red";

    // Validações
    if (!nome || !email || !telefone || !assunto || !mensagem) {
      statusDiv.textContent = "Por favor, preencha todos os campos.";
      return;
    }

    if (nome.length < 3) {
      statusDiv.textContent = "O nome deve ter pelo menos 3 caracteres.";
      return;
    }

    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailValido.test(email)) {
      statusDiv.textContent = "Por favor insira um endereço de e-mail válido (se a sua entrada não estiver no formato email@email.com)";
      return;
    }

    const telefoneValido = /^\d{10,11}$/;
    if (!telefoneValido.test(telefone)) {
      statusDiv.textContent = "Telefone inválido. Use apenas números com DDD (ex: 11999999999).";
      return;
    }

    if (assunto.length > 50) {
      statusDiv.textContent = "O assunto deve ter no máximo 50 caracteres.";
      return;
    }

    if (mensagem.length < 10) {
      statusDiv.textContent = "A mensagem deve conter pelo menos 10 caracteres.";
      return;
    }

    // Se tudo estiver certo:
    statusDiv.textContent = "Mensagem enviada com sucesso!";
    statusDiv.style.color = "green";
    form.reset();
  });
});
